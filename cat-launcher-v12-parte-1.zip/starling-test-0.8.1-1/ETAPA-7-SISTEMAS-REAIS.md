# ETAPA 7 — Cat Launcher controlando os sistemas reais do Starling/Horizon

Cadeia: **index.html → `CatNative.core()` (CatHomeActivity) → `CatCore` (Java) → JNI (`android_lib.rs`) → `cat_bridge.rs` (Rust) → sistemas do jogo**.
Toda resposta é `{"ok":true,...}` ou `{"ok":false,"error":"<motivo do sistema>"}`. O design, as telas e as animações do `index.html` não foram tocados (só JavaScript dos handlers).

## Status geral — leia primeiro
**NADA aqui foi compilado (Rust, Java ou APK) nem rodou em aparelho.** Este ambiente não tem cargo, NDK, SDK, javac nem rede.
O único teste executado foi a *fiação* da página (tests/cat/wiretest.py, Chromium), com um CatNative de teste que só registra as chamadas.
Isso prova que cada botão chama o método certo; **não prova** que o motor responde.

## Mapeamento
| # | Sistema original | Arquivo | Função integrada | Botão do Cat Launcher | Compilado/testado |
|---|---|---|---|---|---|
| 1 | Download dos arquivos oficiais (Mojang, hash por arquivo, retoma) | crates/horizon-client/src/accounts.rs → starling-account/src/files.rs | `accounts::download_files()`, `cancel_download()`, `files()` (progresso real em bytes/arquivos) | Versões → **Instalar** (barra de progresso vem de `state.files`) | Fiação testada (página). Rust/Java: NÃO compilado. Download: NÃO testado |
| 2 | Gerenciamento de versões (a versão que o motor roda: `Pins::starling()`, 26.3) | starling-account/src/files.rs | `cat_bridge::versions_json()` → `listVersions` / `installedVersions` | Tela **Versões** (lista e marca "INSTALADA") | Fiação testada. Resto: NÃO |
| 3 | Remoção dos arquivos | accounts.rs (+ `forget_files()` adicionada) | `cat_bridge::remove_files()` | Versões → **Remover** | NÃO compilado/testado |
| 4 | Contas offline (perfis) | accounts.rs / starling-account/src/profiles.rs | `accounts::add_offline()` (valida 3–16 `[A-Za-z0-9_]`, erro do sistema volta à tela) | **Criar Conta** e **Login** (nome de usuário vira perfil do motor); **JOGAR** garante o perfil | Fiação testada (nome inválido bloqueia, válido segue). Resto: NÃO |
| 5 | Login Microsoft (device code, Xbox/XSTS, posse do Minecraft) | accounts.rs → starling-account/src/lib.rs | `accounts::sign_in()` + `state()` (código/link exibidos; `open_link` abre o navegador) | **Entrar com Microsoft** | Fiação testada. Login real: NÃO |
| 6 | Sair da conta | accounts.rs | `accounts::sign_out()` | Ícone de usuário → sair (sessões Microsoft) | NÃO |
| 7 | Armazenamento seguro de segredos | accounts.rs `SealedStore` + Android Keystore | hooks de plataforma em `cat_bridge::init` → `CatCore.sealSecret/openSecret` (mesma chave `starling-account` do jogo) | (invisível: contas) | NÃO |
| 8 | Skins | horizon-client-render/src/own_skin.rs | `own_skin::decode` + `SkinChoice::save_for_profile` em `cat_bridge::apply_skin` (PNG 64×64 composto na tela; o jogo veste no próximo início) | Personalização → **Salvar** | Fiação: chamada ocorre; sem three.min.js offline o PNG não é gerado (ver limitações). Resto: NÃO |
| 9 | Execução do jogo (GameActivity/NativeActivity, ponte JNI→Rust, `poll_setup` como Play) | android.rs, android_lib.rs, setup/mod.rs, StarlingActivity.java (Etapa 6) | `onCatPlay` + checagens (Android 8+, ARM64, Vulkan 1.1, espaço, nome) | **JOGAR** | Fiação testada. Abrir o Minecraft: NÃO testado |
| 10 | Retorno ao launcher | processos `:cat` / jogo (Manifest, Etapa 6) | o processo do jogo termina; o Android volta à tarefa do Cat Launcher | (ao sair do jogo) | NÃO testado |
| 11 | Logs de execução | android.rs `logcat` (agora `pub(crate)`) | bridge registra `logging::set_console(logcat)`; Java usa `Log` tag `starling` | — (use `adb logcat -s starling:*`) | NÃO |
| 12 | Ponte Java↔Rust↔JNI | android_lib.rs | `Java_..._CatCore_init` / `_call` | todos | NÃO compilado |

## O que NÃO existe no motor (não inventei)
- **Só o Minecraft 26.3**: o motor é uma reescrita em Rust de uma versão só. 1.8.9, 1.21.4, beta etc. não podem ser instalados; a lista mostra o que o motor tem.
- **Preparação de Java**: o motor não usa JVM para jogar (é Rust). O Java só aparece na etapa de preparo dos recursos (`horizon-prepare`/`preparer.rs`), que roda dentro do jogo ao tocar em JOGAR (tela de preparo), não pela ponte.
- **Memória**: não há configuração de heap de JVM a expor; o motor gerencia a sua.
- **Aplicar skin no jogo agora**: o jogo lê a escolha ao iniciar; não há como trocar com o jogo fechado além de gravar a escolha (feito).

## Riscos conhecidos (a verificar no primeiro build)
1. `CatCore.start` carrega `libhorizon_android.so` num processo que não é o da NativeActivity; se alguma inicialização estática da biblioteca exigir a Activity, o carregamento falha e a ponte devolve o erro (aparece na tela).
2. A pasta do jogo (`game_home`) é calculada em `CatCore.start` de forma simplificada em relação a `android.rs::game_folder` (que também migra pastas antigas); só afeta onde a skin é gravada.
3. Nomes JNI e assinaturas foram escritos à mão; um erro de assinatura só aparece em execução.

## Como testar numa máquina com SDK/NDK/Rust
    rustup target add aarch64-linux-android && cargo install cargo-ndk
    python3 packaging/android/build_apk.py --install
    adb logcat -s starling:* chromium:* AndroidRuntime:E
    python3 tests/cat/wiretest.py        # só a fiação da página
Checar: Criar Conta com nome inválido mostra o erro do motor; Versões → Instalar mostra bytes reais; Microsoft mostra código real; JOGAR abre o jogo; sair do jogo volta ao Cat Launcher.
